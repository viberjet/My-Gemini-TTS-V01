import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Download, Volume2, Mic, Sparkles, Globe, FastForward, Lightbulb, Languages, CheckCheck, Users, X, Plus, User } from 'lucide-react';

/**
 * UTILITY: Convert PCM16 (Raw Audio) to WAV
 * The Gemini API returns raw audio data (signed 16-bit PCM).
 * This function wraps it in a valid WAV file header to make it playable
 * in standard HTML <audio> elements and downloadable as a .wav file.
 * @param {Int16Array} pcmData - The raw 16-bit PCM audio data.
 * @param {number} sampleRate - The sample rate of the audio (e.g., 24000).
 * @returns {Blob} A Blob object representing the complete WAV file.
 */
const pcmToWav = (pcmData, sampleRate) => {
  const numChannels = 1;
  const bitsPerSample = 16;
  const bytesPerSample = bitsPerSample / 8;
  const dataSize = pcmData.length * bytesPerSample;
  const blockAlign = numChannels * bytesPerSample;
  const byteRate = sampleRate * blockAlign;

  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  // RIFF header
  view.setUint32(0, 0x52494646, false); // "RIFF"
  view.setUint32(4, 36 + dataSize, true);
  view.setUint32(8, 0x57415645, false); // "WAVE"

  // fmt chunk
  view.setUint32(12, 0x666d7420, false); // "fmt "
  view.setUint32(16, 16, true); // Sub-chunk size (16 for PCM)
  view.setUint16(20, 1, true); // Audio format (1 for PCM)
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitsPerSample, true);

  // data chunk
  view.setUint32(36, 0x64617461, false); // "data"
  view.setUint32(40, dataSize, true);

  // Write PCM data
  for (let i = 0; i < pcmData.length; i++) {
    view.setInt16(44 + i * 2, pcmData[i], true);
  }

  return new Blob([view], { type: 'audio/wav' });
};

/**
 * UTILITY: Decode Base64 to Int16Array
 * @param {string} base64String - The Base64 encoded audio data.
 * @returns {Int16Array}
 */
const base64ToArrayBuffer = (base64String) => {
  const binaryString = window.atob(base64String);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  // Create a new Int16Array from the Uint8Array's buffer.
  // We need to ensure the buffer length is a multiple of 2 (for 16-bit integers)
  const int16 = new Int16Array(
    bytes.buffer,
    0,
    Math.floor(bytes.buffer.byteLength / 2)
  );
  return int16;
};

/**
 * UTILITY: Merge multiple WAV audio files into one
 * Concatenates PCM data from multiple WAV Blobs
 * @param {Blob[]} wavBlobs - Array of WAV Blob objects
 * @param {number} sampleRate - The sample rate of the audio
 * @returns {Blob} A single merged WAV Blob
 */
const mergeWavAudio = async (wavBlobs, sampleRate) => {
  const audioContexts = [];

  for (const blob of wavBlobs) {
    const arrayBuffer = await blob.arrayBuffer();
    const view = new Uint8Array(arrayBuffer);
    
    // Extract PCM data from WAV (skip 44-byte header)
    const pcmLength = Math.floor((arrayBuffer.byteLength - 44) / 2);
    const pcmData = new Int16Array(arrayBuffer, 44, pcmLength);
    audioContexts.push(pcmData);
  }

  // Calculate total length
  const totalLength = audioContexts.reduce((sum, audio) => sum + audio.length, 0);
  
  // Merge all PCM data
  const mergedPcm = new Int16Array(totalLength);
  let offset = 0;
  audioContexts.forEach(audio => {
    mergedPcm.set(audio, offset);
    offset += audio.length;
  });

  return pcmToWav(mergedPcm, sampleRate);
};

// --- FONT IMPORT ---
// We add a <style> tag to the head to import the Vazirmatn font
const fontStyle = document.createElement('style');
fontStyle.innerHTML = `
  @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;7L=00&display=swap');
  .font-vazirmattn {
    font-family: 'Google Vazirmatn', 'Vazirmatn', sans-serif;
  }
`;
document.head.appendChild(fontStyle);

// --- COMPONENT CONSTANTS ---

const VOICES = [
  'zephyr', 'puck', 'charon', 'kore', 'fenrir', 'leda', 'orus', 'aoede',
  'callirrhoe', 'autonoe', 'enceladus', 'iapetus', 'umbriel', 'algieba',
  'despina', 'erinome', 'algenib', 'rasalgethi', 'laomedeia', 'achernar',
  'alnilam', 'schedar', 'gacrux', 'pulcherrima', 'achird', 'zubenelgenubi',
  'vindemiatrix', 'sadachbia', 'sadaltager', 'sulafat'
];

const LANGUAGES = [
  { label: 'English', value: 'English' },
  { label: 'Turkish', value: 'Turkish' },
  { label: 'Persian', value: 'Persian' },
];

const SPEAKING_RATES = [
  { label: 'Slow', value: 'Slow' },
  { label: 'Normal', value: 'Normal' },
  { label: 'Fast', value: 'Fast' },
  { label: 'Very Fast', value: 'Very Fast' },
  { label: 'Extremely Fast', value: 'Extremely Fast' },
];

const PRESET_STYLES = [
  {
    title: "Custom instructions",
    instruction: ""
  },
  {
    title: "Warm, welcoming tone",
    instruction: "Read aloud in a warm, welcoming, and friendly tone. Use a moderate pace and a slightly lower pitch to create a sense of comfort and familiarity. Add brief pauses after commas to feel natural and conversational."
  },
  {
    title: "Professional, informative",
    instruction: "Speak in a professional, informative, and clear tone. Use a steady, moderate pace and a neutral pitch. Enunciate each word precisely. Sound confident and authoritative, as if delivering a news report or a technical presentation."
  },
  {
    title: "Excited and energetic",
    instruction: "Narrate in an excited and energetic voice. Use a faster pace and a higher pitch. Emphasize key positive words with more volume and enthusiasm. Sound genuinely thrilled and upbeat, like a sports commentator or someone sharing great news."
  },
  {
    title: "Calm, soothing tone",
    instruction: "Read in a calm, soothing, and gentle tone. Use a slower pace and a soft, lower pitch. Speak smoothly and evenly, almost like a whisper, to create a relaxing and meditative atmosphere. Ideal for mindfulness or bedtime stories."
  },
  // ... [Other preset styles remain the same] ...
  {
    title: "Poetic, lyrical style",
    instruction: "Read in a poetic, lyrical, and flowing style. Use a slower, rhythmic pace. Vary your pitch to match the emotion of the words. Emphasize the sound and rhythm of the language. Sound reflective, artistic, and deeply feeling."
  }
];

/**
 * A simple loading spinner component.
 */
const SmallSpinner = () => (
  <svg className="animate-spin h-4 w-4 text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
  </svg>
);


const App = () => {
  const [text, setText] = useState('');
  const [styleInstruction, setStyleInstruction] = useState(PRESET_STYLES[1].instruction);
  const [selectedPreset, setSelectedPreset] = useState(PRESET_STYLES[1].title);
  const [selectedVoice, setSelectedVoice] = useState('kore'); // For single speaker mode
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const [speakingRate, setSpeakingRate] = useState('Normal');
  const [audioSrc, setAudioSrc] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isSuggestingStyle, setIsSuggestingStyle] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [isGeneratingText, setIsGeneratingText] = useState(false);
  const [isProofreading, setIsProofreading] = useState(false);
  const audioRef = useRef(null);

  // --- NEW STATE FOR MULTI-SPEAKER ---
  const [mode, setMode] = useState('single'); // 'single' or 'multi'
  const [speakers, setSpeakers] = useState([
    { id: 1, name: 'Speaker 1', voice: 'kore' },
    { id: 2, name: 'Speaker 2', voice: 'puck' }
  ]);

  /**
   * Reusable function to call the Gemini text generation API
   * with exponential backoff.
   */
  const callGeminiTextAPI = async (userQuery, systemPrompt) => {
    const apiKey = "AIzaSyDpAx2XGKrvEAz8Y6Mpohz5g-7fNsrNIX4"; // Use your personal API key
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`;

    const payload = {
      contents: [{ parts: [{ text: userQuery }] }],
      systemInstruction: {
        parts: [{ text: systemPrompt }]
      },
    };

    let response;
    let retries = 0;
    const maxRetries = 5;
    while (retries < maxRetries) {
      try {
        response = await fetch(apiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (response.ok) {
          break; // Success
        } else if (response.status === 429 || response.status >= 500) {
          // Throttling or server error
          retries++;
          if (retries >= maxRetries) {
            throw new Error(`API error: ${response.status} ${response.statusText} after ${maxRetries} retries.`);
          }
          const delay = Math.pow(2, retries + 1) * 1000 + Math.random() * 1000; // Increased backoff
          await new Promise(resolve => setTimeout(resolve, delay));
        } else {
          // Other client-side error
          const errorData = await response.json();
          throw new Error(errorData.error?.message || `API error: ${response.status} ${response.statusText}`);
        }
      } catch (fetchError) {
        if (retries >= maxRetries - 1) {
          throw fetchError;
        }
        retries++;
        const delay = Math.pow(2, retries + 1) * 1000 + Math.random() * 1000; // Increased backoff
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    const result = await response.json();
    const candidate = result.candidates?.[0];

    if (candidate && candidate.content?.parts?.[0]?.text) {
      return candidate.content.parts[0].text;
    } else {
      throw new Error("Invalid response received from text generation API.");
    }
  };


  // --- HELPER: Make a single API call with retry logic ---
  const makeSpeechApiCall = async (prompt, speechConfig, attempt = 1) => {
    const apiKey = "AIzaSyDpAx2XGKrvEAz8Y6Mpohz5g-7fNsrNIX4";
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent?key=${apiKey}`;

    const payload = {
      contents: [{
        parts: [{ text: prompt }]
      }],
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: speechConfig
      },
      model: "gemini-2.5-flash-preview-tts"
    };

    let response;
    let retries = 0;
    const maxRetries = 5;
    
    while (retries < maxRetries) {
      try {
        response = await fetch(apiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (response.ok) {
          break;
        } else if (response.status === 429 || response.status >= 500) {
          retries++;
          if (retries >= maxRetries) {
            if (response.status === 429) {
              throw new Error(`API error: 429 Too Many Requests. You've hit the rate limit. Please wait a moment and try again.`);
            }
            throw new Error(`API error: ${response.status} ${response.statusText} after ${maxRetries} retries.`);
          }
          const delay = Math.pow(2, retries + 1) * 1000 + Math.random() * 1000;
          await new Promise(resolve => setTimeout(resolve, delay));
        } else {
          let errorMessage = `API error: ${response.status} ${response.statusText}`;
          try {
            const errorData = await response.json();
            errorMessage = errorData.error?.message || errorMessage;
          } catch (jsonError) {
            // JSON parsing failed, stick with status text
          }
          throw new Error(errorMessage);
        }
      } catch (fetchError) {
        if (retries >= maxRetries - 1) {
          throw fetchError;
        }
        retries++;
        const delay = Math.pow(2, retries + 1) * 1000 + Math.random() * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    const result = await response.json();
    const part = result?.candidates?.[0]?.content?.parts?.[0];
    const audioData = part?.inlineData?.data;
    const mimeType = part?.inlineData?.mimeType;

    if (audioData && mimeType && mimeType.startsWith("audio/L16")) {
      const sampleRateMatch = mimeType.match(/rate=(\d+)/);
      const sampleRate = sampleRateMatch ? parseInt(sampleRateMatch[1], 10) : 24000;
      const pcmData = base64ToArrayBuffer(audioData);
      const wavBlob = pcmToWav(pcmData, sampleRate);
      return { wavBlob, sampleRate };
    } else {
      throw new Error("Invalid audio data received from API.");
    }
  };

  // --- API Call (UPDATED FOR MULTI-SPEAKER WITH CHUNKING) ---
  const generateSpeech = async () => {
    setLoading(true);
    setError(null);
    setAudioSrc(null);
    setIsPlaying(false);

    // Construct the rate instruction
    let rateInstruction = '';
    if (speakingRate === 'Slow') {
      rateInstruction = 'Speak slowly. ';
    } else if (speakingRate === 'Fast') {
      rateInstruction = 'Speak quickly. ';
    } else if (speakingRate === 'Very Fast') {
      rateInstruction = 'Speak very quickly. ';
    } else if (speakingRate === 'Extremely Fast') {
      rateInstruction = 'Speak extremely quickly. ';
    }

    try {
      if (mode === 'single') {
        // --- SINGLE SPEAKER MODE (unchanged) ---
        const textContent = `"${text}"`;
        const fullPrompt = `${rateInstruction}${styleInstruction}: ${textContent}`;

        const speechConfig = {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: selectedVoice }
          }
        };

        const { wavBlob } = await makeSpeechApiCall(fullPrompt, speechConfig);
        const url = URL.createObjectURL(wavBlob);
        setAudioSrc(url);
      } else {
        // --- MULTI-SPEAKER MODE (with chunking for >2 speakers) ---
        
        // Check if we have more than 2 speakers
        if (speakers.length > 2) {
          const scriptLines = text.split('\n').filter(line => line.trim().length > 0);
          
          // Build a list of speaker chunks needed for the script, in order
          // Group consecutive lines by which speaker appears first, respecting the 2-speaker limit
          const speakerChunks = [];
          let i = 0;
          
          while (i < scriptLines.length) {
            // Find which speaker is in the current line
            const currentLine = scriptLines[i];
            const currentSpeaker = speakers.find(s => currentLine.trim().startsWith(`${s.name}:`));
            
            if (!currentSpeaker) {
              i++;
              continue;
            }
            
            // Start a new chunk with this speaker
            const chunkSpeakers = [currentSpeaker];
            const chunkLines = [currentLine];
            i++;
            
            // Look ahead and add up to one more speaker to fill the chunk (max 2 speakers)
            while (i < scriptLines.length && chunkSpeakers.length < 2) {
              const nextLine = scriptLines[i];
              const nextSpeaker = speakers.find(s => nextLine.trim().startsWith(`${s.name}:`));
              
              if (!nextSpeaker) {
                i++;
                continue;
              }
              
              // Check if this speaker is already in the chunk
              if (!chunkSpeakers.some(s => s.name === nextSpeaker.name)) {
                chunkSpeakers.push(nextSpeaker);
              }
              
              chunkLines.push(nextLine);
              i++;
              
              // If we have 2 speakers, keep going until we find a line with a different speaker
              if (chunkSpeakers.length === 2) {
                const firstTwoSpeakerNames = chunkSpeakers.map(s => s.name);
                while (i < scriptLines.length) {
                  const futureLineSpeaker = speakers.find(s => scriptLines[i].trim().startsWith(`${s.name}:`));
                  if (futureLineSpeaker && firstTwoSpeakerNames.includes(futureLineSpeaker.name)) {
                    chunkLines.push(scriptLines[i]);
                    i++;
                  } else {
                    break;
                  }
                }
                break;
              }
            }
            
            if (chunkLines.length > 0) {
              speakerChunks.push({
                speakers: chunkSpeakers,
                lines: chunkLines
              });
            }
          }
          
          if (speakerChunks.length === 0) {
            throw new Error("No valid speaker audio generated. Make sure your script includes speaker names that match the defined speakers.");
          }

          const wavBlobs = [];
          let requestCount = 0;

          // Process each chunk in order
          for (let chunkIndex = 0; chunkIndex < speakerChunks.length; chunkIndex++) {
            const chunk = speakerChunks[chunkIndex];
            const filteredScript = chunk.lines.join('\n');

            // Build speech config for this chunk
            const speakerVoiceConfigs = chunk.speakers.map(speaker => ({
              speaker: speaker.name,
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: speaker.voice }
              }
            }));

            const speechConfig = {
              multiSpeakerVoiceConfig: {
                speakerVoiceConfigs: speakerVoiceConfigs
              }
            };

            const fullPrompt = `${rateInstruction}${styleInstruction}\n${filteredScript}`;

            // Add delay between requests to avoid rate limiting
            if (requestCount > 0) {
              await new Promise(resolve => setTimeout(resolve, 1000));
            }

            const { wavBlob } = await makeSpeechApiCall(fullPrompt, speechConfig, chunkIndex + 1);
            wavBlobs.push(wavBlob);
            requestCount++;
          }

          // Merge all audio blobs in order
          const mergedWav = await mergeWavAudio(wavBlobs, 24000);
          const url = URL.createObjectURL(mergedWav);
          setAudioSrc(url);
        } else {
          // 1-2 speakers: use the standard API call
          const fullPrompt = `${rateInstruction}${styleInstruction}\n${text}`;

          const speakerVoiceConfigs = speakers.map(speaker => ({
            speaker: speaker.name,
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: speaker.voice }
            }
          }));

          const speechConfig = {
            multiSpeakerVoiceConfig: {
              speakerVoiceConfigs: speakerVoiceConfigs
            }
          };

          const { wavBlob } = await makeSpeechApiCall(fullPrompt, speechConfig);
          const url = URL.createObjectURL(wavBlob);
          setAudioSrc(url);
        }
      }
    } catch (err) {
      console.error("Speech generation failed:", err);
      setError(err.message || "An unknown error occurred.");
    } finally {
      setLoading(false);
    }
  };

  /**
   * ✨ New Feature: Suggest Style
   * Uses Gemini to analyze the input text and suggest a style instruction.
   */
  const suggestStyle = async () => {
    setIsSuggestingStyle(true);
    setError(null);

    const systemPrompt = `You are an expert voice director for text-to-speech. Your job is to analyze text and provide a single, concise, and highly-detailed instruction for the voice model.

Follow this process:
1.  **Analyze (Internal Monologue):** First, analyze the provided text. What is the core emotion (e.g., joy, sadness, anger, formal, casual)? What is the pace (e.g., slow, fast, urgent, relaxed)? What is the intent (e.g., to inform, to persuade, to entertain)?
2.  **Synthesize (Internal Monologue):** Combine these elements into a descriptive persona (e.g., "a professional news anchor," "an excited friend," "a calm meditation guide").
3.  **Final Instruction (Your *Only* Output):** Based on your analysis, write a single, actionable instruction for the voice model. This instruction should be descriptive and clear.

**EXAMPLE:**
**Text:** "I can't believe we won! This is the most amazing day of my entire life!"
**Internal Analysis:**
* Emotion: Extreme joy, excitement, surprise.
* Pace: Fast, energetic, slightly breathless.
* Intent: To express overwhelming happiness.
* Synthesis: An excited friend sharing incredible news.
**Final Instruction (Your Output):** "Speak in an extremely excited and energetic voice. Use a fast pace and a higher pitch to convey overwhelming joy and surprise, adding emphasis to 'amazing'."

Provide *only* the final, synthesized instruction, with no preamble.`;
    const userQuery = `Analyze the following text and provide the final instruction: "${text}"`;

    try {
      const suggestedInstruction = await callGeminiTextAPI(userQuery, systemPrompt);
      // Clean up the response (remove quotes)
      setStyleInstruction(suggestedInstruction.trim().replace(/"/g, ''));
      setSelectedPreset("Custom instructions");
    } catch (err) {
      console.error("Style suggestion failed:", err);
      setError(err.message || "Failed to suggest style.");
    } finally {
      setIsSuggestingStyle(false);
    }
  };

  /**
   * ✨ New Feature: Translate Text
   * Uses Gemini to translate the input text to the selected language.
   */
  const translateText = async () => {
    setIsTranslating(true);
    setError(null);

    const systemPrompt = "You are an expert translator. Your job is to translate text accurately. Provide *only* the translated text, with no preamble or explanations.";
    const userQuery = `Translate the following text to ${selectedLanguage}: "${text}"`;

    try {
      const translatedText = await callGeminiTextAPI(userQuery, systemPrompt);
      setText(translatedText.trim());
    } catch (err) {
      console.error("Translation failed:", err);
      setError(err.message || "Failed to translate text.");
    } finally {
      setIsTranslating(false);
    }
  };

  /**
   * ✨ New Feature: Generate Text from Prompt
   * Uses Gemini to generate new text based on the input text as a prompt.
   */
  const generateTextFromPrompt = async () => {
    setIsGeneratingText(true);
    setError(null);

    const systemPrompt = "You are a creative writing assistant. The user will provide a prompt, and you must generate a short piece of text (e.g., a story, a poem, a paragraph) based on that prompt. Provide *only* the generated text, with no preamble or explanations.";
    const userQuery = `Generate text for this prompt: "${text}"`;

    try {
      const generatedText = await callGeminiTextAPI(userQuery, systemPrompt);
      setText(generatedText.trim());
    } catch (err) {
      console.error("Text generation failed:", err);
      setError(err.message || "Failed to generate text.");
    } finally {
      setIsGeneratingText(false);
    }
  };

  /**
   * ✨ New Feature: Proofread Text
   * Uses Gemini to proofread and correct the input text.
   */
  const proofreadText = async () => {
    setIsProofreading(true);
    setError(null);

    const systemPrompt = "You are an expert editor. The user will provide text. Correct any spelling, grammar, or punctuation errors. Provide *only* the corrected text, with no preamble or explanations. If the text is already perfect, return it unchanged.";
    const userQuery = `Proofread and correct this text: "${text}"`;

    try {
      const correctedText = await callGeminiTextAPI(userQuery, systemPrompt);
      setText(correctedText.trim());
    } catch (err) {
      console.error("Proofreading failed:", err);
      setError(err.message || "Failed to proofread text.");
    } finally {
      setIsProofreading(false);
    }
  };


  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleDownload = () => {
    if (audioSrc) {
      const link = document.createElement('a');
      link.href = audioSrc;
      link.download = 'speech.wav';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handlePresetChange = (e) => {
    const newPresetTitle = e.target.value;
    setSelectedPreset(newPresetTitle);
    
    if (newPresetTitle !== "Custom instructions") {
      const selectedPresetObj = PRESET_STYLES.find(p => p.title === newPresetTitle);
      if (selectedPresetObj) {
        setStyleInstruction(selectedPresetObj.instruction);
      }
    }
  };

  const handleStyleInputChange = (e) => {
    const newInstruction = e.target.value;
    setStyleInstruction(newInstruction);

    // Check if the new text matches a preset's instruction
    const matchingPreset = PRESET_STYLES.find(preset => preset.instruction === newInstruction);
    if (matchingPreset) {
      setSelectedPreset(matchingPreset.title);
    } else {
      setSelectedPreset("Custom instructions");
    }
  };

  // --- NEW HANDLERS FOR MULTI-SPEAKER ---
  const addSpeaker = () => {
    if (speakers.length < 8) {
      setSpeakers([
        ...speakers,
        { id: Date.now(), name: `Speaker ${speakers.length + 1}`, voice: 'zephyr' }
      ]);
    }
  };

  const removeSpeaker = (idToRemove) => {
    // Keep at least one speaker
    if (speakers.length > 1) {
      setSpeakers(speakers.filter(speaker => speaker.id !== idToRemove));
    }
  };

  const updateSpeaker = (index, field, value) => {
    const newSpeakers = [...speakers];
    newSpeakers[index] = { ...newSpeakers[index], [field]: value };
    setSpeakers(newSpeakers);
  };
  // --- END NEW HANDLERS ---


  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 font-sans flex flex-col items-center py-8 px-4 sm:px-6">
      
      {/* --- Main Application Card --- */}
      <div className="w-full max-w-2xl bg-gray-900 border border-gray-700 rounded-2xl shadow-2xl overflow-hidden">
        
        {/* Header */}
        <header className="p-6 sm:p-8 border-b border-gray-700">
          <h1 className="text-3xl font-bold text-blue-400">
            Gemini Text-to-Speech
          </h1>
          <p className="text-base text-gray-400 mt-2">
            Turn your text into natural-sounding audio with AI.
          </p>
        </header>

        {/* Input Area */}
        <div className="p-6 sm:p-8 border-b border-gray-700">
          
          {/* Style Preset Dropdown */}
          <label htmlFor="preset-select" className="block text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">
            Style Presets
          </label>
          <div className="relative mb-4">
            <select
              id="preset-select"
              value={selectedPreset}
              onChange={handlePresetChange}
              className="w-full appearance-none bg-gray-800 border border-gray-700 text-white py-3 px-4 pr-8 rounded-lg leading-tight focus:outline-none focus:bg-gray-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500 transition-colors cursor-pointer font-medium"
            >
              {PRESET_STYLES.map((preset) => (
                <option key={preset.title} value={preset.title}>
                  {preset.title}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
              <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
            </div>
          </div>

          {/* Style Instruction Input */}
          <div className="flex justify-between items-center mb-2">
            <label htmlFor="style-input" className="block text-xs font-semibold uppercase tracking-wider text-gray-500">
              Style instructions (Editable)
            </label>
            <button
              onClick={suggestStyle}
              disabled={isSuggestingStyle || !text || loading || isGeneratingText || isProofreading || isTranslating}
              className="flex items-center text-xs font-medium text-blue-400 hover:text-blue-300 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
            >
              {isSuggestingStyle ? (
                <SmallSpinner />
              ) : (
                <Lightbulb className="w-4 h-4" />
              )}
              <span className="ml-1.5">✨ Suggest Style</span>
            </button>
          </div>
          <textarea
              id="style-input"
              rows="3"
              className="w-full p-3 text-sm bg-gray-800 border-2 border-gray-700 rounded-xl focus:border-blue-500 focus:bg-gray-700 focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-gray-500 text-gray-100 font-vazirmattn mb-4 resize-none h-28"
              placeholder="e.g., Read in a happy tone"
              value={styleInstruction}
              onChange={handleStyleInputChange}
          />

          <label htmlFor="text-input" className="block text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">
            Input Text {mode === 'multi' && '(include speaker names, e.g., "Speaker 1: ...")'}
          </label>
          <textarea
            id="text-input"
            rows="6"
            maxLength="100000"
            dir="auto"
            className="w-full p-4 text-base bg-gray-800 text-gray-100 rounded-xl focus:bg-gray-700 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all placeholder:text-gray-500 font-vazirmattn resize-y"
            placeholder={mode === 'single' ? "Type your text here..." : "Type your multi-speaker script here...\n\nSpeaker 1: Hello! We're excited to show you...\nSpeaker 2: Where you can direct a voice..."}
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          {/* Character count and new AI buttons */}
          <div className="flex justify-between items-center mt-2">
            {/* AI Buttons */}
            <div className="flex space-x-2">
              <button
                onClick={generateTextFromPrompt}
                disabled={isGeneratingText || !text || loading || isProofreading || isSuggestingStyle || isTranslating}
                className="flex items-center text-xs font-medium text-blue-400 hover:text-blue-300 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                title="Treat the input text as a prompt and generate new text"
              >
                {isGeneratingText ? (
                  <SmallSpinner />
                ) : (
                  <Sparkles className="w-4 h-4" />
                )}
                <span className="ml-1.5">✨ Generate Text</span>
              </button>

              <button
                onClick={proofreadText}
                disabled={isProofreading || !text || loading || isGeneratingText || isSuggestingStyle || isTranslating}
                className="flex items-center text-xs font-medium text-blue-400 hover:text-blue-300 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                title="Proofread and correct spelling/grammar"
              >
                {isProofreading ? (
                  <SmallSpinner />
                ) : (
                  <CheckCheck className="w-4 h-4" />
                )}
                <span className="ml-1.5">✨ Proofread</span>
              </button>
            </div>

            {/* Character Count */}
            <div className="text-right text-xs font-medium text-gray-500">
              {text.length} / 100000
            </div>
          </div>
        </div>

        {/* Configuration Area */}
        <div className="p-6 sm:p-8 border-b border-gray-700">

          {/* --- NEW MODE TOGGLE --- */}
          <div className="mb-6">
            <label className="block text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">
              Mode
            </label>
            <div className="flex w-full bg-gray-800 border border-gray-700 rounded-lg p-1">
              <button
                onClick={() => setMode('single')}
                className={`flex-1 flex items-center justify-center py-2 px-3 rounded-md text-sm font-medium transition-colors ${mode === 'single' ? 'bg-blue-600 text-white shadow' : 'text-gray-300 hover:bg-gray-700'}`}
              >
                <User className="w-4 h-4 mr-2" />
                Single Speaker
              </button>
              <button
                onClick={() => setMode('multi')}
                className={`flex-1 flex items-center justify-center py-2 px-3 rounded-md text-sm font-medium transition-colors ${mode === 'multi' ? 'bg-blue-600 text-white shadow' : 'text-gray-300 hover:bg-gray-700'}`}
              >
                <Users className="w-4 h-4 mr-2" />
                Multi-Speaker
              </button>
            </div>
          </div>
          {/* --- END MODE TOGGLE --- */}


          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            
            {/* --- VOICE CONFIGURATION (DYNAMIC) --- */}
            {mode === 'single' ? (
              <div>
                <label htmlFor="voice-select" className="flex items-center text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">
                  <Mic className="w-4 h-4 mr-1.5" />
                  Voice
                </label>
                <div className="relative">
                  <select
                    id="voice-select"
                    value={selectedVoice}
                    onChange={(e) => setSelectedVoice(e.target.value)}
                    className="w-full appearance-none bg-gray-800 border border-gray-700 text-white py-3 px-4 pr-8 rounded-lg leading-tight focus:outline-none focus:bg-gray-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500 transition-colors cursor-pointer font-medium"
                  >
                    {VOICES.map((voice) => (
                      <option key={voice} value={voice}>{voice.charAt(0).toUpperCase() + voice.slice(1)}</option>
                    ))}
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                    <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                  </div>
                </div>
              </div>
            ) : (
              /* --- NEW MULTI-SPEAKER UI --- */
              <div className="sm:col-span-2">
                <div className="flex justify-between items-center mb-2">
                  <label className="flex items-center text-xs font-semibold uppercase tracking-wider text-gray-500">
                    <Users className="w-4 h-4 mr-1.5" />
                    Speakers (Max 8)
                  </label>
                  <button
                    onClick={addSpeaker}
                    disabled={speakers.length >= 8}
                    className="flex items-center text-xs font-medium text-blue-400 hover:text-blue-300 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span className="ml-1">Add Speaker</span>
                  </button>
                </div>
                <div className="space-y-3">
                  {speakers.map((speaker, index) => (
                    <div key={speaker.id} className="flex items-center space-x-2 bg-gray-800 p-2 rounded-lg border border-gray-700">
                      <input
                        type="text"
                        value={speaker.name}
                        onChange={(e) => updateSpeaker(index, 'name', e.target.value)}
                        placeholder="Speaker Name"
                        className="flex-1 w-1/3 bg-gray-700 border border-gray-600 text-white py-2 px-3 rounded-md text-sm focus:outline-none focus:bg-gray-600 focus:border-blue-500"
                      />
                      <div className="relative w-1/2">
                        <select
                          value={speaker.voice}
                          onChange={(e) => updateSpeaker(index, 'voice', e.target.value)}
                          className="w-full appearance-none bg-gray-700 border border-gray-600 text-white py-2 px-3 pr-8 rounded-md text-sm leading-tight focus:outline-none focus:bg-gray-600 focus:border-blue-500 transition-colors cursor-pointer"
                        >
                          {VOICES.map((voice) => (
                            <option key={voice} value={voice}>{voice.charAt(0).toUpperCase() + voice.slice(1)}</option>
                          ))}
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                          <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
D                        </div>
                      </div>
                      <button
                        onClick={() => removeSpeaker(speaker.id)}
                        disabled={speakers.length <= 1}
                        className="flex-shrink-0 text-gray-500 hover:text-red-400 disabled:text-gray-700 disabled:cursor-not-allowed transition-colors p-2"
                        aria-label="Remove Speaker"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-2">Note: Your script's speaker names (e.g., "Speaker 1:") must exactly match the names defined here.</p>
              </div>
              /* --- END MULTI-SPEAKER UI --- */
            )}
            
            {/* --- OTHER SETTINGS --- */}
            <div className={mode === 'single' ? '' : 'sm:col-start-1'}>
              <label htmlFor="rate-select" className="flex items-center text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">
                <FastForward className="w-4 h-4 mr-1.5" />
                Speaking Rate
              </label>
              <div className="relative">
                <select
                  id="rate-select"
                  value={speakingRate}
                  onChange={(e) => setSpeakingRate(e.target.value)}
                  className="w-full appearance-none bg-gray-800 border border-gray-700 text-white py-3 px-4 pr-8 rounded-lg leading-tight focus:outline-none focus:bg-gray-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500 transition-colors cursor-pointer font-medium"
                >
                  {SPEAKING_RATES.map((rate) => (
                    <option key={rate.value} value={rate.value}>{rate.label}</option>
                  ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                  <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                </div>
              </div>
            </div>

            <div className={mode === 'single' ? '' : 'sm:col-start-2'}>
              <div className="flex justify-between items-center mb-2">
                <label htmlFor="lang-select" className="flex items-center text-xs font-semibold uppercase tracking-wider text-gray-500">
                  <Globe className="w-4 h-4 mr-1.5" />
                  Language (for Translate)
                </label>
                <button
                  onClick={translateText}
                  disabled={isTranslating || !text || selectedLanguage === 'English' || loading || isGeneratingText || isProofreading || isSuggestingStyle}
                  className="flex items-center text-xs font-medium text-blue-400 hover:text-blue-300 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                  title={selectedLanguage === 'English' ? "Select a language other than English to translate" : "Translate text"}
                >
                  {isTranslating ? (
                    <SmallSpinner />
                  ) : (
                    <Languages className="w-4 h-4" />
                  )}
                  <span className="ml-1.5">✨ Translate</span>
                </button>
              </div>
              <div className="relative">
                <select
                  id="lang-select"
                  value={selectedLanguage}
                  onChange={(e) => setSelectedLanguage(e.target.value)}
                  className="w-full appearance-none bg-gray-800 border border-gray-700 text-white py-3 px-4 pr-8 rounded-lg leading-tight focus:outline-none focus:bg-gray-700 focus:border-blue-500 focus:ring-2 focus:ring-blue-500 transition-colors cursor-pointer font-medium"
                >
                  {LANGUAGES.map((lang) => (
                    <option key={lang.value} value={lang.value}>{lang.label}</option>
                  ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                  <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-2">Assumes input text is English.</p>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="p-6 sm:p-8">
          <button
            onClick={generateSpeech}
            disabled={loading || !text || (mode === 'multi' && speakers.length === 0) || isSuggestingStyle || isTranslating || isGeneratingText || isProofreading}
            className="w-full flex items-center justify-center bg-blue-600 text-white font-bold py-4 px-6 rounded-xl hover:bg-blue-700 focus:outline-none focus:ring-4 focus:ring-blue-400 transition-all shadow-lg hover:shadow-xl hover:shadow-blue-500/20 disabled:bg-gray-600 disabled:text-gray-400 disabled:shadow-none disabled:cursor-not-allowed"
          >
            {loading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2.5" />
                Generate Speech
              </>
            )}
          </button>
        </div>

        {/* Error Display */}
        {error && (
          <div className="px-6 sm:px-8 pb-6">
            <div className="bg-red-900/30 border border-red-700 text-red-300 px-4 py-3 rounded-lg" role="alert">
              <strong className="font-bold">Error: </strong>
              <span className="block sm:inline">{error}</span>
            </div>
          </div>
        )}

        {/* Audio Player */}
        {audioSrc && !loading && (
          <div className="p-6 sm:p-8 border-t border-gray-700 bg-gray-900">
            <h3 className="text-lg font-semibold text-gray-200 mb-4">Your Audio</h3>
            <div className="flex items-center space-x-4">
              <button
                onClick={togglePlay}
                className="flex-shrink-0 bg-blue-600 text-white p-3 rounded-full hover:bg-blue-700 focus:outline-none focus:ring-4 focus:ring-blue-400 transition-all"
                aria-label={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
              </button>
              <audio
                ref={audioRef}
                src={audioSrc}
                onEnded={() => setIsPlaying(false)}
                className="w-full"
                controls
              />
              <button
                onClick={handleDownload}
                className="flex-shrink-0 bg-gray-700 text-gray-200 p-3 rounded-full hover:bg-gray-600 focus:outline-none focus:ring-4 focus:ring-gray-600 transition-all"
                aria-label="Download"
              >
                <Download className="w-6 h-6" />
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default App;